<?php
include('bdd.php');


if(isset($_POST['submit'])) {
   $pseudo = htmlspecialchars($_POST['pseudo']);
   $mail = $_POST['mail'];
   $mdp = sha1($_POST['mdp1']);
   $mdp2 = sha1($_POST['mdp2']);
   if(!empty($_POST['pseudo']) AND !empty($_POST['mdp1']) AND !empty($_POST['mdp2']) AND !empty($_POST['mail'])) {
      $pseudolength = strlen($pseudo);
      if($pseudolength <= 255) {

         $reqpseudo = $connexion->prepare("SELECT pseudo FROM profil WHERE pseudo = ?");
         $reqpseudo->execute(array($pseudo));
         $pseudoexist = $reqpseudo->rowcount();
         if ($pseudoexist == 0) {

         	 $reqmail = $connexion->prepare("SELECT mail FROM profil WHERE mail = ?");
	         $reqmail->execute(array($mail));
	         $mailexist = $reqmail->rowcount();
	         if ($mailexist == 0) {

	            if($mdp == $mdp2) {
	               $insertmbr = $connexion->prepare("INSERT INTO profil(pseudo, mdp, mail) VALUES(?, ?, ?)");
	               $insertmbr->execute(array($pseudo, $mdp, $mail));
	               $erreur = "Votre compte a bien été crée";


	               $req = $connexion->prepare('SELECT id_membre FROM profil WHERE pseudo = :pseudo AND mdp = :mdp1 AND mail = :mail');
	               $req->execute(array('pseudo' => $pseudo,'mdp1' => $mdp, 'mail' => $mail));
	               $resultat = $req->fetch();

	                session_start();
		            $_SESSION['pseudo'] = $pseudo;
		            $_SESSION['id_membre'] = $resultat->id_membre;
		            if (isset($_GET['url'])){
		            	$referer = $_GET['url'];
		            	header('Location:'.$referer);
		            }else{
		            	header('Location: index.php');
		            }



            	}else {
               		$erreur = "Vos mots de passes ne correspondent pas !";
           		}
         	}else{
            	$erreur = "Cette mail existe déja !";
        	}
        }else{
            $erreur = "Cette idendifiant existe déja !";
        }

      }else {
         $erreur = "Votre pseudo ne doit pas dépasser 255 caractères !";
      }
   }else {
      $erreur = "Tous les champs doivent être complétés !";
   }

}
?>







<!DOCTYPE html>
<html>
<head>
	<title>Inscription || La Rencontre</title>
	<!--   Lien de nos feuille de style -->
  <link rel="stylesheet" href="styleall.css">
  <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0" />

  <!-- ---->
  <link rel="stylesheet" href="https://use.typekit.net/fmb4ffg.css">
 <link href="https://fonts.googleapis.com/css?family=Kaushan+Script|Lobster|Roboto&display=swap" rel="stylesheet">
</head>
<body>
	<div class='section1'>
		<div class='fenetre' id='popupInscription'>
	      <div class="inscription" id='popupInscription'>
	        <h1 class="titre">Inscription</h1>
	        <div class="contenu">
	          <form action="" method="POST">
	            <div class='containerCon_Ins'>
	              <div>
	                <label>Pseudo</label>
	                <br>
	                <input class="case" type="text" value="<?php if(isset($_POST['pseudo'])){echo $_POST['pseudo'];} ?>" name="pseudo" />
	              </div>
	              <div>
	                <label>Mail</label>
	                <br>
	                <input class="case" type="mail" value="<?php if(isset($_POST['mail'])){echo $_POST['mail'];} ?>" name="mail" />
	              </div>
	              <div>
	                <label>Mot de passe</label>
	                <br>
	                <input class="case" type="password" value="" name="mdp1" />
	              </div>
	              <div>
	                <label>Confirmation mot de passe</label>
	                <br>
	                <input class="case" type="password" value="" name="mdp2" />
	              </div>

	              <div>
	                <div class="blockbutton">
	                  <input class='buttonCon_Ins' type="submit" name='submit' value="Inscrivez-vous" />
	                </div>
	                 <p class='redirectionCompte'>déjà client ? <a href='connexion.php'>Connectez-vous ici.</a>
	                 <?php
	                	if(isset($erreur)){
	                		echo '<p class="erreur">'.$erreur.'</p>';
	                	}else{

	                	}
	                ?>
	              </div>
	            </div>
	          </form>
	        </div>
	      </div>
	    </div>
	</div>
</body>
</html>