<?php
include('bdd.php');
$req = $connexion->prepare('SELECT * FROM groupe WHERE id_groupe = :id_groupe');
$req->execute(array('id_groupe' => $_GET['id_groupe']));
$infoGroupe = $req->fetch();


session_start();
if(isset($_SESSION['id_membre']) && isset($_SESSION['pseudo'])){
  if(isset($_POST['message'])AND !empty($_POST['message'])){
    $message = htmlspecialchars($_POST['message']);

    $query = $connexion->prepare('INSERT INTO messages SET pseudo = :pseudo, message = :message, dateCreation = NOW(), id_groupe = :id_groupe');

    $query->execute([
      "pseudo" => $_SESSION['pseudo'],
      "message" => $message,
      "id_groupe" => $_GET['id_groupe']
    ]);
  }
}

?>




<!DOCTYPE html>
<html lang="fr" dir="ltr">

<head>
  <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0" />
  <!--   Lien de nos feuille de style -->
  <link rel="stylesheet" href="styleall.css">
  <!-- ---->
  <link rel="stylesheet" href="https://use.typekit.net/fmb4ffg.css">
 <link href="https://fonts.googleapis.com/css?family=Kaushan+Script|Lobster|Roboto&display=swap" rel="stylesheet">
 <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.css">
  <title>Discussions</title>
</head>

<body class="page">

 <?php include('header.php');?>

  <!-- END HEADER -->


  <div class="pageConversation">

    <div class='headerChat'>
      <div class="titreMessagePage">
        <h1 class="titrePage"><?php echo $infoGroupe->categorie;?></h1>
        <p class="titreConv"><?php echo $infoGroupe->titre;?></p>
      </div>
      <div class="infoConv">
        <div class="onlineBloc">
          <div class='cercle2 online onlineConv'></div>
          <p class="onlinePeople">14 membres en parlent</p>
        </div>
        <button type="button" name="button" class="boutonRetour"><a href='GroupList.php?sport=<?php echo $infoGroupe->categorie;?>&liste=8'>Retour</a></button>
      </div>
    </div>
   



     <div class="blocConversation" id='blocConversation'>
    <?php
      if(isset($_SESSION['id_membre']) && $_SESSION['pseudo']){
        $pseudo = $_SESSION['pseudo'];
      }else{
        $pseudo ='';
      }

      $allmsg = $connexion->query("SELECT * FROM messages WHERE id_groupe='".$_GET['id_groupe']."' ORDER BY id_message DESC LIMIT  20");
      $allmsg->execute();
      $msg = $allmsg->fetchAll();

      $boucle = count($msg) -1;
      while($boucle >= 0){

      $req = $connexion->prepare('SELECT image_profil, premium FROM profil WHERE pseudo = :pseudo');
      $req->execute(array('pseudo' => $msg[$boucle]->pseudo));
      $img = $req->fetch();
      $heure = explode(":", $msg[$boucle]->dateCreation);
      if(isset($_SESSION['pseudo']) && $_SESSION['pseudo'] == $msg[$boucle]->pseudo){?>

        <div class="ligneMsg ligneMsgDroite">
          <p class="heureMsg heureMsgDroite"><?php echo $heure[0].'h'.$heure[1]; ?></p>
          <div class="messageEnvoye msgDroite">
            <p class='pseudoD'><?php if($img->premium == 'default'){ echo $msg[$boucle]->pseudo; }else{ echo'<img src="img/crown.svg" alt="Compte premium ou administrateur" class="imagePseudo">'.$msg[$boucle]->pseudo; }?></p>
            <p class="contenuMsg"><?php echo $msg[$boucle]->message ?></p>
           </div>
          <div class="iconeUserD">
            <img src="<?php echo $img->image_profil;?>"/>
          </div>
        </div>

      <?php    
      }else{?>
         <div class="ligneMsg">
          <div class="iconeUserG">
            <img src="<?php echo $img->image_profil;?>"/>
          </div>
          <div class="messageEnvoye msgGauche">
            <p class='pseudoG'><?php if($img->premium == 'default'){ echo $msg[$boucle]->pseudo; }else{ echo'<img src="img/crown.svg" alt="Compte premium ou administrateur" class="imagePseudo">'.$msg[$boucle]->pseudo; }?></p>
            <p class="contenuMsg"><?php echo $msg[$boucle]->message ?></p>
          </div>
          <p class="heureMsg heureMsgGauche"><?php echo $heure[0].'h'.$heure[1]; ?></p>
        </div>

        <?php 
        }
        $boucle--;
      }
          ?>



      <!--------------- -->
    </div>
    <form class="formulaireConv" action="" method="post">
      <?php 
      if (isset($_SESSION['id_membre'])){?>
         <input type="text" name="message" value="" placeholder="Saisir le message ici..." autocomplete="off">
      <?php
      }else{
        ?>
          <p>Connectez-vous pour envoyer un message <a href='connexion.php?url=<?php echo $url; ?>'>Connexion</a></p>
        <?php
      }?>
    
     
      <div class="boutonEnvoi">
        <input type='submit' name='submit' value=' ' class='validationMess'/>
      </div>

      <!--<button type="submit" name="button" class="boutonEnvoi"><img src="img/avion.svg" alt="" class="logoEnvoi"></button>-->
    </form>
  </div>

  <?php include('footer.php');?>

   <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="  crossorigin="anonymous"> </script>

    <script type="text/javascript">
      // ---- fenetre choix inscription connexion ---//

      $(document).ready(function(){
        console.log('1');
        element = document.getElementById('blocConversation');
        element.scrollTop = element.scrollHeight;

        $('#profil').click(function(){
          $('#myPopup').toggle(5);
        });
      
      });

        setInterval('load_messages()', 500);
        var test = "<?php echo $_GET['id_groupe'];?>";
        var pseudo = "<?php echo $pseudo;?>";
        console.log(test); 
        console.log(pseudo); 
        function load_messages(){
          $('#blocConversation').load('load_message.php?id_groupe='+test+'&pseudo='+pseudo);
        }



    </script>
</body>

</html>
