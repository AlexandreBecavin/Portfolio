<?php
require 'bdd.php';
$req = $connexion->prepare('SELECT * FROM newsletter WHERE mail = :mail');
$req->execute(array('mail' => $_POST['email']));
$resultat = $req->fetch();

if(isset($resultat->mail)){
	echo 1;
}else{
	echo 0;
}
?>