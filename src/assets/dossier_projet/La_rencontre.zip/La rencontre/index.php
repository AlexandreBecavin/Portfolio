<?php
session_start();
?>

<!DOCTYPE html>
<html lang="fr" dir="ltr">

<head>
  <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0" />
  <!--   Lien de nos feuille de style -->
  <link rel="stylesheet" href="styleall.css">
  <!-- ---->
  <link rel="stylesheet" href="https://use.typekit.net/fmb4ffg.css">
  <link href="https://fonts.googleapis.com/css?family=Kaushan+Script|Lobster|Roboto&display=swap" rel="stylesheet">
   <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.css">

    


  <title>Accueil</title>
</head>

<body>
  <a id='haut'></a>
  <div class="fullpage">
    <div class="section1">
      <div class="filtreNoir">

        <?php include('header.php'); ?>

        <div class="slogan">
          <p class="accroche">Le bar</p>
          <p class="accroche">comme si vous y étiez !</p>
          <h1 class="sloganPhrase">A consommer sans modération</h1>
        </div>
        <div id="animChevon"></div>
      </div>
    </div>
    <div class="section2">
      <div id="cercle"></div>
      <div class="info-direct">
        <p>Direct : </p>
        <p class="match-direct"><span>Football</span> : Angers vs Toulouse ----- <span>Hockey</span> : Les Ducs d'Angers vs Lyon Hocky ----- <span>Football</span> : Angers vs Toulouse ----- <span>Hockey</span> : Les Ducs d'Angers vs Lyon Hocky -----
          <span>Football</span> </p>
      </div>







      <div class="blockSport">



        <!-- section sur le foot -->
        <div class="titre-article">
          <h2>Football :</h2>
        </div>

        <div class="blockArticle">
          <!-- article 1 -->
          <div class="article">
            <div class="scoreTimer">

              <div class="info-score">
                <div class="equipe-score equipe1">
                  <p>Angers</p>
                  <p>0</p>
                </div>
                <div class="equipe-score equipe2">
                  <p>Toulouse</p>
                  <p>0</p>
                </div>
              </div>
              <div class="timer">
                <p>5"</p>
              </div>
            </div>

            <div class="form-match-direct">
              <button type="button" name="button" class="bouton1"><a href='groupList.php?sport=Football&liste=8'>Rejoindre une discussion</a></button>
              <button type="button" name="button" class="bouton2"><a href='group_creation.php'>Créer une discussion</a></button>
            </div>
          </div>

          <!-- article 2 -->

          <div class="article">
            <div class="scoreTimer">

              <div class="info-score">
                <div class="equipe-score equipe1">
                  <p>Angers</p>
                  <p>0</p>
                </div>
                <div class="equipe-score equipe2">
                  <p>Toulouse</p>
                  <p>0</p>
                </div>
              </div>

              <div class="timer">
                <p>5"</p>
              </div>
            </div>

            <div class="form-match-direct">
              <button type="button" name="button" class="bouton1"><a href='groupList.php?sport=Football&liste=8'>Rejoindre une discussion</a></button>
              <button type="button" name="button" class="bouton2"><a href='group_creation.php'>Créer une discussion</a></button>
            </div>
          </div>

          <!-- article 3 -->

          <div class="article">
            <div class="scoreTimer">

              <div class="info-score">
                <div class="equipe-score equipe1">
                  <p>Angers</p>
                  <p>0</p>
                </div>
                <div class="equipe-score equipe2">
                  <p>Toulouse</p>
                  <p>0</p>
                </div>
              </div>

              <div class="timer">
                <p>5"</p>
              </div>
            </div>

            <div class="form-match-direct">
              <button type="button" name="button" class="bouton1"><a href='groupList.php?sport=Football&liste=8'>Rejoindre une discussion</a></button>
              <button type="button" name="button" class="bouton2"><a href='group_creation.php'>Créer une discussion</a></button>
            </div>
          </div>

          <!-- article 4 -->

          <div class="article">
            <div class="scoreTimer">

              <div class="info-score">
                <div class="equipe-score equipe1">
                  <p>Angers</p>
                  <p>0</p>
                </div>
                <div class="equipe-score equipe2">
                  <p>Toulouse</p>
                  <p>0</p>
                </div>
              </div>

              <div class="timer">
                <p>5"</p>
              </div>
            </div>

            <div class="form-match-direct">
              <button type="button" name="button" class="bouton1"><a href='groupList.php?sport=Football&liste=8'>Rejoindre une discussion</a></button>
              <button type="button" name="button" class="bouton2"><a href='group_creation.php'>Créer une discussion</a></button>
            </div>
          </div>
        </div>






        <!-- section sur le hockey -->






        <div class="titre-article">
          <h2>Hockey :</h2>
        </div>
        <div class="blockArticle">

          <!-- article 1 -->
          <div class="article">
            <div class="scoreTimer">

              <div class="info-score">
                <div class="equipe-score equipe1">
                  <p>Angers</p>
                  <p>0</p>
                </div>
                <div class="equipe-score equipe2">
                  <p>Toulouse</p>
                  <p>0</p>
                </div>
              </div>

              <div class="timer">
                <p>5"</p>
              </div>
            </div>

            <div class="form-match-direct">
              <button type="button" name="button" class="bouton1"><a href='groupList.php?sport=Hockey&liste=8'>Rejoindre une discussion</a></button>
              <button type="button" name="button" class="bouton2"><a href='group_creation.php'>Créer une discussion</a></button>
            </div>
          </div>

          <!-- article 2 -->

          <div class="article">
            <div class="scoreTimer">

              <div class="info-score">
                <div class="equipe-score equipe1">
                  <p>Angers</p>
                  <p>0</p>
                </div>
                <div class="equipe-score equipe2">
                  <p>Toulouse</p>
                  <p>0</p>
                </div>
              </div>

              <div class="timer">
                <p>5"</p>
              </div>
            </div>

            <div class="form-match-direct">
              <button type="button" name="button" class="bouton1"><a href='groupList.php?sport=Hockey&liste=8'>Rejoindre une discussion</a></button>
              <button type="button" name="button" class="bouton2"><a href='group_creation.php'>Créer une discussion</a></button>
            </div>
          </div>

          <!-- article 3 -->

          <div class="article">
            <div class="scoreTimer">

              <div class="info-score">
                <div class="equipe-score equipe1">
                  <p>Angers</p>
                  <p>0</p>
                </div>
                <div class="equipe-score equipe2">
                  <p>Toulouse</p>
                  <p>0</p>
                </div>
              </div>

              <div class="timer">
                <p>5"</p>
              </div>
            </div>

            <div class="form-match-direct">
              <button type="button" name="button" class="bouton1"><a href='groupList.php?sport=Hockey&liste=8'>Rejoindre une discussion</a></button>
              <button type="button" name="button" class="bouton2"><a href='group_creation.php'>Créer une discussion</a></button>
            </div>
          </div>

          <!-- article 4 -->

          <div class="article">
            <div class="scoreTimer">

              <div class="info-score">
                <div class="equipe-score equipe1">
                  <p>Angers</p>
                  <p>0</p>
                </div>
                <div class="equipe-score equipe2">
                  <p>Toulouse</p>
                  <p>0</p>
                </div>
              </div>

              <div class="timer">
                <p>5"</p>
              </div>
            </div>

            <div class="form-match-direct">
              <button type="button" name="button" class="bouton1"><a href='groupList.php?sport=Hockey&liste=8'>Rejoindre une discussion</a></button>
              <button type="button" name="button" class="bouton2"><a href='group_creation.php'>Créer une discussion</a></button>
            </div>
          </div>
        </div>




        <!-- section sur le handball -->





        <div class="titre-article">
          <h2>Rugby :</h2>
        </div>
        <div class="blockArticle">
          <!-- article 1 -->
          <div class="article">
            <div class="scoreTimer">

              <div class="info-score">
                <div class="equipe-score equipe1">
                  <p>Angers</p>
                  <p>0</p>
                </div>
                <div class="equipe-score equipe2">
                  <p>Toulouse</p>
                  <p>0</p>
                </div>
              </div>

              <div class="timer">
                <p>5"</p>
              </div>
            </div>

            <div class="form-match-direct">
              <button type="button" name="button" class="bouton1"><a href='groupList.php?sport=Rugby&liste=8'>Rejoindre une discussion</a></button>
              <button type="button" name="button" class="bouton2"><a href='group_creation.php'>Créer une discussion</a></button>
            </div>
          </div>

          <!-- article 2 -->

          <div class="article">
            <div class="scoreTimer">

              <div class="info-score">
                <div class="equipe-score equipe1">
                  <p>Angers</p>
                  <p>0</p>
                </div>
                <div class="equipe-score equipe2">
                  <p>Toulouse</p>
                  <p>0</p>
                </div>
              </div>

              <div class="timer">
                <p>5"</p>
              </div>
            </div>

            <div class="form-match-direct">
              <button type="button" name="button" class="bouton1"><a href='groupList.php?sport=Rugby&liste=8'>Rejoindre une discussion</a></button>
              <button type="button" name="button" class="bouton2"><a href='group_creation.php'>Créer une discussion</a></button>
            </div>
          </div>

          <!-- article 3 -->

          <div class="article">
            <div class="scoreTimer">

              <div class="info-score">
                <div class="equipe-score equipe1">
                  <p>Angers</p>
                  <p>0</p>
                </div>
                <div class="equipe-score equipe2">
                  <p>Toulouse</p>
                  <p>0</p>
                </div>
              </div>

              <div class="timer">
                <p>5"</p>
              </div>
            </div>

            <div class="form-match-direct">
              <button type="button" name="button" class="bouton1"><a href='groupList.php?sport=Rugby&liste=8'>Rejoindre une discussion</a></button>
              <button type="button" name="button" class="bouton2"><a href='group_creation.php'>Créer une discussion</a></button>
            </div>
          </div>

          <!-- article 4 -->

          <div class="article">
            <div class="scoreTimer">

              <div class="info-score">
                <div class="equipe-score equipe1">
                  <p>Angers</p>
                  <p>0</p>
                </div>
                <div class="equipe-score equipe2">
                  <p>Toulouse</p>
                  <p>0</p>
                </div>
              </div>

              <div class="timer">
                <p>5"</p>
              </div>
            </div>

            <div class="form-match-direct">
              <button type="button" name="button" class="bouton1"><a href='groupList.php?sport=Rugby&liste=8'>Rejoindre une discussion</a></button>
              <button type="button" name="button" class="bouton2"><a href='group_creation.php'>Créer une discussion</a></button>
            </div>
          </div>

        </div>
      </div>
      <!-- blockSport -->
      <div class="bloc2">
        <div class="calendrier">
          <h3 class="calTitre">Calendrier des matchs</h3>
          <div class="sport1">
            <p class="nomSportCal">Football :</p>
            <div class="blockMatch">
              <div class="matchCalendrier">
                <div class="match1">
                  <div class="equipe">
                    <p>Angers</p>
                    <p>PSG</p>
                  </div>
                  <div class="dateMatch">
                    <p class="date">30/01/2020</p>
                    <p class="heure">20:00</p>
                  </div>
                </div>
                <div class="match1">
                  <div class="equipe">
                    <p>Angers</p>
                    <p>PSG</p>
                  </div>
                  <div class="dateMatch">
                    <p class="date">30/01/2020</p>
                    <p class="heure">20:00</p>
                  </div>
                </div>
                <div class="match1">
                  <div class="equipe">
                    <p>Angers</p>
                    <p>PSG</p>
                  </div>
                  <div class="dateMatch">
                    <p class="date">30/01/2020</p>
                    <p class="heure">20:00</p>
                  </div>
                </div>
                <div class="match1">
                  <div class="equipe">
                    <p>Angers</p>
                    <p>PSG</p>
                  </div>
                  <div class="dateMatch">
                    <p class="date">30/01/2020</p>
                    <p class="heure">20:00</p>
                  </div>
                </div>

              </div>
              <p class="infoSupCal">- - voir plus - -</p>
            </div>



            <p class="nomSportCal">Hockey :</p>
            <div class="blockMatch">
              <div class="matchCalendrier">
                <div class="match1">
                  <div class="equipe">
                    <p>Angers</p>
                    <p>PSG</p>
                  </div>
                  <div class="dateMatch">
                    <p class="date">30/01/2020</p>
                    <p class="heure">20:00</p>
                  </div>
                </div>
                <div class="match1">
                  <div class="equipe">
                    <p>Angers</p>
                    <p>PSG</p>
                  </div>
                  <div class="dateMatch">
                    <p class="date">30/01/2020</p>
                    <p class="heure">20:00</p>
                  </div>
                </div>
                <div class="match1">
                  <div class="equipe">
                    <p>Angers</p>
                    <p>PSG</p>
                  </div>
                  <div class="dateMatch">
                    <p class="date">30/01/2020</p>
                    <p class="heure">20:00</p>
                  </div>
                </div>
                <div class="match1">
                  <div class="equipe">
                    <p>Angers</p>
                    <p>PSG</p>
                  </div>
                  <div class="dateMatch">
                    <p class="date">30/01/2020</p>
                    <p class="heure">20:00</p>
                  </div>
                </div>

              </div>
              <p class="infoSupCal">- - voir plus - -</p>
            </div>



            <p class="nomSportCal">Rugby :</p>
            <div class="blockMatch">
              <div class="matchCalendrier">
                <div class="match1">
                  <div class="equipe">
                    <p>Angers</p>
                    <p>PSG</p>
                  </div>
                  <div class="dateMatch">
                    <p class="date">30/01/2020</p>
                    <p class="heure">20:00</p>
                  </div>
                </div>
                <div class="match1">
                  <div class="equipe">
                    <p>Angers</p>
                    <p>PSG</p>
                  </div>
                  <div class="dateMatch">
                    <p class="date">30/01/2020</p>
                    <p class="heure">20:00</p>
                  </div>
                </div>
                <div class="match1">
                  <div class="equipe">
                    <p>Angers</p>
                    <p>PSG</p>
                  </div>
                  <div class="dateMatch">
                    <p class="date">30/01/2020</p>
                    <p class="heure">20:00</p>
                  </div>
                </div>
                <div class="match1">
                  <div class="equipe">
                    <p>Angers</p>
                    <p>PSG</p>
                  </div>
                  <div class="dateMatch">
                    <p class="date">30/01/2020</p>
                    <p class="heure">20:00</p>
                  </div>
                </div>

              </div>

              <p class="infoSupCal">- - voir plus - -</p>
            </div>
          </div>
        </div>

        <div class="actu">
          <h3 class="titreBlockActu">Actualitées</h3>
          <div class="contenuActu">
            <h4 class="titreActu">Victoires des Bleus</h4>
            <p>Lorem ipsum dolor sit amet
              consectetur adipiscing elit.</p>
            <h4 class="titreActu">Victoires des Bleus</h4>
            <p>Lorem ipsum dolor sit amet
              consectetur adipiscing elit.</p>
            <h4 class="titreActu">Victoires des Bleus</h4>
            <p>Lorem ipsum dolor sit amet
              consectetur adipiscing elit.</p>
            <h4 class="titreActu">Victoires des Bleus</h4>
            <p>Lorem ipsum dolor sit amet
              consectetur adipiscing elit.</p>
            <h4 class="titreActu">Victoires des Bleus</h4>
            <p>Lorem ipsum dolor sit amet
              consectetur adipiscing elit.</p>
            <h4 class="titreActu">Victoires des Bleus</h4>
            <p>Lorem ipsum dolor sit amet
              consectetur adipiscing elit.</p>
            <h4 class="titreActu">Victoires des Bleus</h4>
            <p>Lorem ipsum dolor sit amet
              consectetur adipiscing elit.</p>
            <h4 class="titreActu">Victoires des Bleus</h4>
            <p>Lorem ipsum dolor sit amet
              consectetur adipiscing elit.</p>
            <h4 class="titreActu">Victoires des Bleus</h4>
            <p>Lorem ipsum dolor sit amet
              consectetur adipiscing elit.</p>
            <h4 class="titreActu">Victoires des Bleus</h4>
            <p>Lorem ipsum dolor sit amet
              consectetur adipiscing elit.</p>
          </div>
        </div>

      </div>
      <!-- fin du bloc2 -->
      <div class="blockDiscussions">
        <h3 class="titreBlockDiscu">Discussions populaires</h3>
        <div class="ligneDiscussion">
          <div class="discussion">
            <div class="titreDiscu">
              <p>Ici c'est Paris</p>
              <p>45 ligne</p>
              <div class="cercle2"></div>
            </div>
            <p class="desc">Si t'es fan du PSG,
              viens ici pour
              discuter !</p>
            <p class="nomCreateur">créé par <span>@ultraPSG</span></p>
            <button type="button" name="button" class="boutonDiscu">Rejoindre la discussion</button>

          </div>

          <div class="discussion">
            <div class="titreDiscu">
              <p>Ici c'est Paris</p>
              <p>45 ligne</p>
              <div class="cercle2"></div>
            </div>
            <p class="desc">Si t'es fan du PSG,
              viens ici pour
              discuter !</p>
            <p class="nomCreateur">créé par <span>@ultraPSG</span></p>
            <button type="button" name="button" class="boutonDiscu">Rejoindre la discussion</button>

          </div>

          <div class="discussion">
            <div class="titreDiscu">
              <p>Ici c'est Paris</p>
              <p>45 ligne</p>
              <div class="cercle2"></div>
            </div>
            <p class="desc">Si t'es fan du PSG,
              viens ici pour
              discuter !</p>
            <p class="nomCreateur">créé par <span>@ultraPSG</span></p>
            <button type="button" name="button" class="boutonDiscu">Rejoindre la discussion</button>

          </div>

          <div class="discussion">
            <div class="titreDiscu">
              <p>Ici c'est Paris</p>
              <p>45 ligne</p>
              <div class="cercle2"></div>
            </div>
            <p class="desc">Si t'es fan du PSG,
              viens ici pour
              discuter !</p>
            <p class="nomCreateur">créé par <span>@ultraPSG</span></p>
            <button type="button" name="button" class="boutonDiscu">Rejoindre la discussion</button>

          </div>


        </div>
      </div>

      <?php include('footer.php');?>

    </div>
      <a href="#haut" class="retourHaut"><i class="fas fa-arrow-up"></i></a>
  </div>

  <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
  <script src="https://kit.fontawesome.com/b51ebbfc71.js" crossorigin="anonymous"></script>
  <script>
  $(window).scroll(function () {
    //console.log( $(window).scrollTop() );
    if ($(window).scrollTop() > 100) {
      $('.retourHaut').fadeIn(300);
    } else {
      $('.retourHaut').fadeOut(100);

    }
  });


  // ---- fenetre choix inscription connexion ---//
    $(document).ready(function(){
      $('#profil').click(function(){
        $('#myPopup').toggle(5);
    });
    });




  </script>


</body>

</html>
