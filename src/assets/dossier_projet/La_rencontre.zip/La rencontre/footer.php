<footer>
    <div class='containerFooter'>
    	<div class='logoFooter'>
    		<a href="index.php"><img src='img/logo+nom.png' alt='logo du site'/></a>
    	</div>
    	<div class='navFooter'>
    		<div class='nav1'>
	        	<a href='categorie.php'>Discussion</a>
	    		<a href='map.php'>Où regarder?</a>
	    		<a>Devenir Premium</a>			
    		</div>
    		<div>
    			<p>Ne manquez aucune rencontre ! <a id='newsletter'>Souscrivez à notre newsletter</a></p>
    		</div>
    	</div>
    	<div class='rsFooter'>
    		<div>
    			<a><img src="img/facebook.png" alt='Reseau social facebook'></a>
    			<a><img src="img/twitter.png" alt='Reseau social twitter'></a>
    			<a><img src="img/instagram.png" alt='Reseau social instagram'></a>
    		</div>
    		<div>
    			<p><a href='mentions_legales.php'>Mentions légales</a> | <a>CGU</a> | <a>CGV</a></p>
    		</div>
    	</div>
    </div>
 </footer>

 <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.min.js"></script>
 <script>
 $(document).ready(function(){
    $('#newsletter').click(function(){
     swal({
     title: 'Inscrivez-vous à la newsletter',
     input: 'email',
     showCancelButton: true,
     confirmButtonText: 'Envoyer',
     showLoaderOnConfirm: true,
     preConfirm: function (email) {
     return new Promise(function (resolve, reject) {
     setTimeout(function() {
         $.ajax({
         type: 'post',
         url: 'check_email.php',
         data: {email:email},
         success: function(result){
         if(result>0){
            reject('Votre adresse mail est déjà renseignée.')
         }
         else{
             $.ajax({
             type: 'post',
             url: 'subscribe.php',
             data: {email:email},
             success: function(data){
             resolve()
             }
             });
         
         }
         }
         });
     
     }, 1000)
     })
     },
     allowOutsideClick: true
         }).then(function (email) {
         swal({
             type: 'success',
             title: 'Vous êtes inscrit à notre newsletter',
             html: 'Adresse mail: ' + email
         })
     })
     });
 });
</script>