<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Le Concept</title>
	<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0" />
	<!--   Lien de nos feuille de style -->
	<link rel="stylesheet" href="styleall.css">
	<!-- ---->
	<link rel="stylesheet" href="https://use.typekit.net/fmb4ffg.css">
	<link href="https://fonts.googleapis.com/css?family=Kaushan+Script|Lobster|Roboto&display=swap" rel="stylesheet">
	 <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.css">


</head>
<body>
	<?php include('header.php');?>

	<section class='concept'>
		<h1>Le Concept</h1>
		<hr>
		<div class='containerConcept'>
			<div class='infoConcept1'>
				<p>La Rencontre est un site dédié au débat sportif. Le but est de créer un lieu de rencontre virtuel autour du sport et de pouvoir passer du virtuel au réel en rencontrant les utilisateurs dans les bars qui diffusent du sport.</br></br> Le nom « La Rencontre » était donc une évidence puisqu’il fait référence à une rencontre sportive mais aussi à une rencontre avec une ou plusieurs personnes virtuellement ou en réel. Il est vraiment important pour nous d’amener les gens à se rencontrer « IRL ».</p>
			</div>
			
			<div class='infoConcept2'>
				<img src='img/concept.jpg'/>
			</div>
		</div>
	</section>
	<section class='fonctionnalites'>
		<h2>Nos Fonctionnalités</h2>
		<p>Découvrez nos différentes fonctionnalités pour discuter sports et rencontrer des passionnés, comme vous !</p>
		<hr>
		<div class='containerPointFort'>
			<div>
				<img src='img/chat.png'>
				<p>Créez ou rejoignez des discutions spécialisées dans les sports que vous préférez !</p>
			</div>
			<div>
				<img src='img/localisation.png'>
				<p>Explorez et découvrez notre carte des bars partenaires et rencontrez les utilisateurs !</p>
			</div>
			<div>
				<img src='img/premium.png'>
				<p>Profitez d’avantages Premium afin de gagner en visibilité et de découvrir d’autres fonctionnalités !</p>
			</div>
		</div>
	</section>
	<section class='equipeConcept'>
		<h2>Notre équipe</h2>
		<p>Découvrez toute l’équipe La Rencontre</p>
		<hr>
		<div class='createur'>
			<div>
				<img src='img/mael.jpg' alt='créateur mael'/>
				<h4>Mael RICHARD</h4>
				<p>UI/UX Design<br>Marketing</p>
			</div>
			<div>
				<img src='img/axel.jpeg' alt='créateur axel'/>
				<h4>Axel CHIRON</h4>
				<p>UI/UX Design<br>Marketing</p>
			</div>
			<div>
				<img src='img/alexandre.jpg' alt='créateur Alexandre'/>
				<h4>Alexandre BECAVIN</h4>
				<p>Développer Front/Back<br>UI/UX Design</p>
			</div>
			<div>
				<img src='img/louis.jpg' alt='créateur Louis'/>
				<h4>Louis FRESNEAU</h4>
				<p>UI/UX Design<br>Marketing</p>
			</div>
		</div>
	</section>
	<section class='chiffre'>
		<div>
			<img src='img/communautaire.png' alt='Membre deja inscrit'/>
			<p>Plus de 3500 membres déjà inscrit sur La Rencontre</p>
		</div>
		<div>
			<img src='img/chat2.png' alt='conversations créées'/>
			<p>Plus de 600 conversations créées entre les membres</p>
		</div>
		<div>
			<img src='img/biere.png' alt='bars partenaires'/>
			<p>Plus de 35 bars partenaires dans toute la France</p>
		</div>
	</section>
	<section class='temoignages'>
		<h2>Témoignages</h2>
		<p>Découvrez ce que nos utilisateurs pensent de notre concept.</p>
		<hr>

		<div class="carrousel">						
			<input type="radio" name="slides" id="radio-1" checked>
			<input type="radio" name="slides" id="radio-2">
			<input type="radio" name="slides" id="radio-3">
			<input type="radio" name="slides" id="radio-4">
			<ul class="slides">
				<li class="slide">
            		<p>
              			<span class="author">
              			<img src="img/mael.jpg">
              			</span>
              			<q>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis delenitiatque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.</q>
            		</p>
           		</li>        
	            <li class="slide">
	              	<p>
	               		<span class="author">
              			<img src="img/mael.jpg">
              			</span>
              			<q>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis delenitiatque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.</q>
	              	</p>
	           	</li>
	          	<li class="slide">
	            	<p>
	                	<span class="author">
              			<img src="img/mael.jpg">
              			</span>
              			<q>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis delenitiatque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.</q>
	             	</p>
	          	</li>
	          	<li class="slide">
	            	<p>
	              		<span class="author">
              			<img src="img/mael.jpg">
              			</span>
              			<q>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis delenitiatque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.</q>
	            	</p>
	           	</li>
			</ul>
			<div class="slidesNavigation">
				<label for="radio-1" id="dotForRadio-1"></label>
				<label for="radio-2" id="dotForRadio-2"></label>
				<label for="radio-3" id="dotForRadio-3"></label>
				<label for="radio-4" id="dotForRadio-4"></label>
			</div>
		</div>




	</section>
	<?php include('footer.php');?>

</body>
</html>