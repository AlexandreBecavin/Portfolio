<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Où regarder</title>
	<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0" />
	<!--   Lien de nos feuille de style -->
	<link rel="stylesheet" href="styleall.css">
	<!-- ---->
	<link rel="stylesheet" href="https://use.typekit.net/fmb4ffg.css">
	<link href="https://fonts.googleapis.com/css?family=Kaushan+Script|Lobster|Roboto&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.css">

	
</head>
<body>
	<?php include('header.php');?>

    <section>

    	<!--------Titre---------->
		<div class='bandeau'>
    		<img src='img/localisation.png' alt='icone localisation'/>
    		<h1>Où regarder ?</h1>
    	</div>	
    	

    	<!-- Carte Interactive -->
    	<div class='containerMap'>
    		<iframe src="https://www.google.com/maps/d/u/0/embed?mid=1EtpfKWPx3eXsr8xd0ItB-6dx2v68jfCu"></iframe>
    	</div>
    	<div class='mapInscription'>
    		<p>Vous êtes professionnel et vous diffusez du sport. Inscrivez vous pour faire référencer votre établissement sur notre carte</p>
    		<a href='inscription_bar.html'>Inscription de votre établissement</a>
    	</div>

    	<?php include('footer.php');?>
		
		<script
			  src="https://code.jquery.com/jquery-3.4.1.min.js"
			  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
              crossorigin="anonymous">
        </script>
		<script type="text/javascript">
			// ---- fenetre choix inscription connexion ---//
			$(document).ready(function(){
			  $('#profil').click(function(){
			    $('#myPopup').toggle(5);
			});
			});



		</script>

    </section>
</body>
</html>



