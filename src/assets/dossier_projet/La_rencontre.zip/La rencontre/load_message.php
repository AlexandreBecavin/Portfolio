<?php

include('bdd.php');
$allmsg = $connexion->query("SELECT * FROM messages WHERE id_groupe='".$_GET['id_groupe']."' ORDER BY id_message DESC LIMIT  20");
$allmsg->execute();
$msg = $allmsg->fetchAll();

$boucle = count($msg) -1;
while($boucle >= 0){
	$req = $connexion->prepare('SELECT image_profil, premium FROM profil WHERE pseudo = :pseudo');
    $req->execute(array('pseudo' => $msg[$boucle]->pseudo));
    $img = $req->fetch();
    $heure = explode(":", $msg[$boucle]->dateCreation);

	if(isset($_GET['pseudo']) && $_GET['pseudo'] == $msg[$boucle]->pseudo){?>

	  <div class="ligneMsg ligneMsgDroite">
	    <p class="heureMsg heureMsgDroite"><?php echo $heure[0].'h'.$heure[1]; ?></p>
	    <div class="messageEnvoye msgDroite">
	      <p class='pseudoD'><?php if($img->premium == 'default'){ echo $msg[$boucle]->pseudo; }else{ echo'<img src="img/crown.svg" alt="Compte premium ou administrateur" class="imagePseudo">'.$msg[$boucle]->pseudo; }?></p>
	      <p class="contenuMsg"><?php echo $msg[$boucle]->message ?></p>
	    </div>
	    <div class="iconeUserD">
	      <img src="<?php echo $img->image_profil;?>"/>
	    </div>
	  </div>

	<?php    
	}else{?>
	   <div class="ligneMsg">
	    <div class="iconeUserG">
	      <img src="<?php echo $img->image_profil;?>"/>
	    </div>
	    <div class="messageEnvoye msgGauche">
	      <p class='pseudoG'><?php if($img->premium == 'default'){ echo $msg[$boucle]->pseudo; }else{ echo'<img src="img/crown.svg" alt="Compte premium ou administrateur" class="imagePseudo">'.$msg[$boucle]->pseudo; }?></p>
	      <p class="contenuMsg"><?php echo $msg[$boucle]->message ?></p>
	    </div>
	    <p class="heureMsg heureMsgGauche"><?php echo $heure[0].'h'.$heure[1]; ?></p>
	  </div>

	 <?php 
	}
	$boucle--;
}
      ?>