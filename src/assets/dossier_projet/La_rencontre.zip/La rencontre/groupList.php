<?php
if(isset($_POST['recherche'])){
	$recherche = $_POST['recherche'];
}else{
	$recherche = '';
}

session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Liste des Groupes</title>
	<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0" />
	<!--   Lien de nos feuille de style -->
	<link rel="stylesheet" href="styleall.css">
	<!-- ---->
	<link rel="stylesheet" href="https://use.typekit.net/fmb4ffg.css">
	<link href="https://fonts.googleapis.com/css?family=Kaushan+Script|Lobster|Roboto&display=swap" rel="stylesheet">
	 <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.css">

</head>
<body>
	<?php include('header.php');?>

	 <div class='titreGroup'>
	 	 <img src='img/<?php echo $_GET['sport'];?>.svg' alt='icon du sport'/>
	 	 <h1> <?php echo $_GET['sport'];?></h1>      
	 </div>

	 <div class='recherche'>
	 	<p><?php echo $_GET['sport'];?> </p>
	 	<form action='' method='post'>
	 		<input type="text" name="recherche" placeholder="recherche">
	 		<input type='image' src='img/loupe' onclick='submit'>
	 	</form>
	 </div>

	 <div class='groupList'>
	 	<h2>Discussions populaires</h2>
	 	<hr>


	 	<?php
	 	include('bdd.php');
	 	$sport = $_GET['sport'];
		$allgroupe = $connexion->query("SELECT * FROM groupe WHERE categorie='$sport' AND titre LIKE '%".$recherche."%' ORDER BY date_creation DESC LIMIT 0, ".$_GET['liste']."");

		
		$allgroupe->execute();
		$groups = $allgroupe->fetchAll();

		foreach ($groups as $value) {
			if($value->premium == 'premium' || $value->premium == 'admin'){
				?>
				<div class='containerGroup'>
			 		<div class='imageGroup'>
			 			<img src='img/img_groupe/groupe<?php echo $_GET['sport']; echo $value->type;?>.svg'/>
			 		</div>
			 		<div class='titreGroupe'>
			 			<h3><?php echo $value->titre;?></h3>
			 			<div class='infoGroup'>
			 				<p>By <span class='red'><img alt='premium' src='img/crown.svg'/><?php echo $value->createur;?></span> | <?php echo $value->date_creation;?></p>
			 			</div>
			 		</div>
			 		<div class='callToAction'>
			 			<div class='onlineGroup'>
			 				<span class='rondVert'></span><p> 13 en ligne</p>
			 			</div>
			 			<a class='buttonRejoindre' href="message.php?id_groupe=<?php echo $value->id_groupe;?>">REJOINDRE</a> 
			 		</div>
			 	</div>
	 	<?php
			}
		}

		foreach ($groups as $value) {
			if($value->premium == 'default'){
				?>
				<div class='containerGroup'>
			 		<div class='imageGroup'>
			 			<img src='img/img_groupe/groupe<?php echo $_GET['sport']; echo $value->type;?>.svg'/>
			 		</div>
			 		<div class='titreGroupe'>
			 			<h3><?php echo $value->titre;?></h3>
			 			<div class='infoGroup'>
			 				<p>By <span class='red'><?php echo $value->createur;?></span> | <?php echo $value->date_creation;?></p>
			 			</div>
			 		</div>
			 		<div class='callToAction'>
			 			<div class='onlineGroup'>
			 				<span class='rondVert'></span><p> 13 en ligne</p>
			 			</div>
			 			<a class='buttonRejoindre' href="message.php?id_groupe=<?php echo $value->id_groupe;?>">REJOINDRE</a> 
			 		</div>
			 	</div>
	 	<?php
			}
		}
		?>

		<div class='buttonCharger'>
			<a class='chargerPlus' href='groupList.php?sport=<?php echo $_GET["sport"];?>&liste=<?php echo $_GET["liste"]+8?>'>Charger plus</a>
		</div>
	 </div>

	 <div class="infoCreation">
	 	<h2>En manque de débats ?</h2>
	 	<img src="img/chatNoir.svg" alt="inforamtion creation groupe"/>
	 	<br>
	 	<a href='group_creation.php'>Créer une discussion</a>
	 </div>
	 <div class='premium'>
		 <div class='infoPremium'>
		 	<div>
				<img src='img/premium.png'/>
				<p>Profitez dès maintenant des avantages d’un compte Premium</p>  	 		
		 	</div>
		 	<div>
				<img src='img/sale.svg'/>
				<p>Un tarif unique de 4,99€ chaque mois pour plus de fonctionnalités !</p>  	 		
		 	</div>
		 </div>
	 	<a>Devenir premium</a>
	</div>
	<?php include('footer.php');?>
</body>
</html>