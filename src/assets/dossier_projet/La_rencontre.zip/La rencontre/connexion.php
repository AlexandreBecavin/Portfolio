<?php
// Hachage du mot de passe
$pass="";
$pseudo="";
 
if (isset($_GET['url'])){
	$url = $_GET['url'];
}else{
	$url = 'index.php';
}

if(isset($_POST['submit'])) {
    $pass = sha1($_POST['mdp']);
    $pseudo = htmlspecialchars($_POST['pseudo']);

    if ($pass == "" or $pseudo == ""){
        $erreur = 'Veuillez remplir tous les champs';

    }
    else{
        include('bdd.php');
        $req = $connexion->prepare('SELECT id_membre FROM profil WHERE pseudo = :pseudo AND mdp = :pass');

        $req->execute(array('pseudo' => $pseudo,'pass' => $pass));

        $resultat = $req->fetch();

        if (!$resultat){
            $erreur = 'Mauvais identifiant ou mot de passe !';
        }else{
            session_start();
            $_SESSION['pseudo'] = $pseudo;
            $_SESSION['id_membre'] = $resultat->id_membre;
            if (isset($_GET['url'])){
            	$referer = $_GET['url'];
            	header('Location:'.$referer);
            }else{
            	header('Location: index.php');
            }
            
        }
    }
}

?>



<!DOCTYPE html>
<html>
<head>
	<title>Connexion || La Rencontre</title>
	<!--   Lien de nos feuille de style -->
  <link rel="stylesheet" href="styleall.css">
  	<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0" />

  <!-- ---->
  <link rel="stylesheet" href="https://use.typekit.net/fmb4ffg.css">
  <link href="https://fonts.googleapis.com/css?family=Kaushan+Script|Lobster|Roboto&display=swap" rel="stylesheet">
</head>
<body>
	<div class='section1'>
		<div class='fenetre' id='popupConnexion'>
	      <div class="connexion">
	        <h1 class="titre">Connexion</h1>
	        <div class="contenu">
	          <form action="" method="post">
	            <div class='containerCon_Ins'>
	              <div>
	                <label>Pseudo</label>
	                <br>
	                <input class="case" type="text" value="<?php if(isset($_POST['pseudo'])){echo $_POST['pseudo'];} ?>" name="pseudo" />
	              </div>
	              <div>
	                <label>Mot de passe</label>
	                <br>
	                <input class="case" type="password" value="" name="mdp" />
	              </div>

	              <div>
	                <div class="blockbutton">
	                  <input class='buttonCon_Ins' type="submit" value="Connectez-vous" name='submit'/>
	                </div>
	                <p class='redirectionCompte'>Nouveau client ? <a href='inscription.php?url=<?php echo $url;?>'>Commencer ici.</a>
	                <?php
	                	if(isset($erreur)){
	                		echo '<p class="erreur">'.$erreur.'</p>';
	                	}else{

	                	}
	                ?>
	              </div>
	            </div>
	          </form>
	        </div>
	      </div>
	    </div>
	</div>
</body>
</html>