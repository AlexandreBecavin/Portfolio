<?php

session_start();
if (isset($_SESSION['id_membre']) AND isset($_SESSION['pseudo'])){

	include('bdd.php');


	if(isset($_POST['submit'])) {
	   if(isset($_POST['titre']) AND isset($_POST['sport']) AND isset($_POST['categorie']) AND !empty($_POST['sport']) AND !empty($_POST['categorie']) AND $_POST['sport'] != 'nosport' AND $_POST['categorie'] != 'default'){
	   		if(strlen($_POST['titre']) <= 60){

	   			$pseudo = $_SESSION['pseudo'];
	   			$reqgroupe = $connexion->prepare("SELECT createur FROM groupe WHERE createur = ?");
         		$reqgroupe->execute(array($pseudo));
         		$groupeexist = $reqgroupe->rowcount();

	   			$reqpremium = $connexion->prepare("SELECT premium FROM profil WHERE pseudo = ?");
         		$reqpremium->execute(array($pseudo));
         		$premium = $reqpremium->fetch();

         		var_dump($premium->premium);
         		var_dump($groupeexist);

         		if($premium->premium == 'default' && $groupeexist <= 2 || $premium->premium == 'premium' && $groupeexist <= 5 || $premium->premium == 'admin'){
	               	$insertGr = $connexion -> prepare("INSERT INTO `groupe`(`titre`, `createur`, `date_creation`, `categorie`, `type`, `premium`) VALUES (:titre, :createur, NOW(), :categorie, :type, :premium)");
					$insertGr -> execute([
						":titre" =>$_POST['titre'],
						":createur" => $pseudo,
						":categorie" => $_POST['sport'],
						":type" => $_POST['categorie'],
						":premium" => $premium->premium
					]);

					$reqid = $connexion->prepare("SELECT id_groupe FROM groupe WHERE titre = ? ORDER BY id_groupe DESC");
         			$reqid->execute(array($_POST['titre']));
         			$id_groupe = $reqid->fetch();
         			header('location: message.php?id_groupe='.$id_groupe->id_groupe);


         		}else{
         			if($premium->premium == 'default'){
         				$erreur = 'Veuillez passer sur un compte premium';
         			}else{
         				$erreur = "supprimez des groupes pour pouvoir en créer d'autre";
         			}
         		}

	   		}else{
	   			$erreur = 'titre trop long';
	   		}
	   }else{
	   	$erreur = "Veuillez rempli tous les champs";
	   }

	}
	?>





	<!DOCTYPE html>
	<html>
	<head>
		<title>Création de groupe</title>
		<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0" />
		<!--   Lien de nos feuille de style -->
		<link rel="stylesheet" href="styleall.css">
		<!-- ---->
		<link rel="stylesheet" href="https://use.typekit.net/fmb4ffg.css">
		<link href="https://fonts.googleapis.com/css?family=Kaushan+Script|Lobster|Roboto&display=swap" rel="stylesheet">
		  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.css">
	</head>
	<body>
		<?php include('header.php');?>

			<div class="pageCreationG">
				<h1>Création de groupe</h1>
				<hr>
				<div class='containerCreaG'>
					<div>
						<p>Créez votre groupe pour parler avec d'autres amateurs de sport sur le sujet de votre choix !</p>
						<div class='containerIcone'>
							<div class='carteCreaG'>
								<img src='img/chat.png'/>
								<p>Débattez sur le sujet de votre choix</p>
							</div>
							<div class='carteCreaG'>
								<img src='img/biereR.png'/>
								<p>Rencontrez de nouvelles personnes</p> 
							</div>
						</div>
					</div>
					<div class='formGrCreation'>
						<form action='' method='post'>
							<div>
								<label>Titre de la discussion</label>
								<input type="text" name="titre"/>
							</div>
							<div>
								<select name='sport' class='choixsport'>
									<option selected value="nosport" class='sport1'>Choisissez votre sport</option>
									<option value="Football" class='sport1'>Football</option>
									<option value="Basketball" class='sport1'>Basketball</option>
									<option value="Hockey" class='sport1'>Hockey</option>
									<option value="Rugby">Rugby</option>
									<option value="Tennis">Tennis</option>
									<option value="Autres">Autres</option>
								</select>
							</div>
							<div>
								<select name='categorie' class='categorie'>
									<option selected class='sport' value='default'>Choisissez la categorie</option>
									<option value="match" class='nosport ChoixTennis'>match</option>
									<option value="transfert" class='nosport NoTennis'>transfert</option>
									<option value="joueur" class='nosport ChoixTennis'>Joueur</option>
									<option value="Autres" class='nosport ChoixTennis'>Autres</option>
								</select>
							</div>
							<div>
								<input type="submit" name="submit" value="C'est parti">
							</div>
							<?php 
							if(isset($erreur)){
								echo $erreur;
							}else{

							}


							?>
						</form>
					</div>
				</div>
			</div>
		<div class='footerGrCreation'>
			<?php include('footer.php');?>
		</div>

		<script
			  src="https://code.jquery.com/jquery-3.4.1.min.js"
			  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
	          crossorigin="anonymous">
	    </script>
		
	    <script type="text/javascript">



	    	$(document).ready(function(){
	    		$('.sport').show();
	    		$('.nosport').hide();

	    		$("select.choixsport").change(function(){
	    			$('.categorie').prop('selectedIndex',0);

			        var sport = $(this).children("option:selected").val();
			        if(sport == 'Football' || sport == 'Basketball' || sport == 'Hockey' || sport == 'Rugby' || sport == 'Autres'){
			        	$('.nosport').show();
			        }else if(sport == 'Tennis'){
			        	$('.ChoixTennis').show();
			        	$('.NoTennis').hide();
			        }else{
			        	$('.nosport').hide();
			        }
			     });

	    	});
	    </script>
	</body>
	</html>
<?php
}else{
	$url = 'group_creation.php';
	header('location:  connexion.php?url='.$url );
}