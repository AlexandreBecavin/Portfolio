<!--HEADER START -->
        <?php 
        $url = $_SERVER['REQUEST_URI'];

        ?>
        <header class="header">

        <div class="nomSiteLogo">
            <div class="blockLogo">
                <a href="index.php"><img src="img/logo.svg" alt="logo du site" class="logo"></a>
            </div>
            <span class="nomSite">La Rencontre</span>
        </div>
        <div id='formatTelClose' class='formatTelClose'>
          <div class='formatTel' id='formatTel'>
             <a class="toggleOff" id="toggleOff" href='#formatTelClose'>
              <div class='croix'>
                <img src="img/CroixMenu.svg">
              </div>
            </a>

          <div class='navigation' id='navigation'>
              <nav class="nav">
                  <ul class="blockList">
                      <li><a href="concept.php">Le concept</a></li>
                      <li><a href="categorie.php">Discussions</a></li>
                      <li><a href="map.php">Où regarder ?</a></li>
                  </ul> 
              </nav>
          </div>

          <div class='blockRechercheBoutton'>

              <div class="boutonConnexion">
                <span id='profil'><?php if(isset($_SESSION['id_membre'])){?><a href='profil.php'><?php }else{?> <a href='connexion.php'> <?php }?> <img src='img/profil.svg' alt='profil'/><p>Profil</p></a></span>
                <span id='notif'><a><img src='img/notif.svg' alt='notif'/><p>Notification</p></a></span>
              </div>
          </div>
          </div>
      </div>

        <a class="toggle" id="toggle" href="#formatTel">
          <div class='menuTel'>
            <span></span>
            <span></span>
            <span></span>
          </div>
        </a>
    </header>
    <hr class="barreRouge">
    <!--HEADER END -->