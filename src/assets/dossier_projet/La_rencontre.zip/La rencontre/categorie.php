<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Catégorie | La rencontre</title>
	<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0" />
	<!--   Lien de nos feuille de style -->
	<link rel="stylesheet" href="styleall.css">
	<!-- ---->
	<link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Kaushan+Script|Lobster|Roboto&display=swap" rel="stylesheet">
     <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.css">

</head>
<body>
	<?php include('header.php');?>



	<section class='sportCartes'>


		<article class='contenu'>
			<div class='foot'>
				<h2 class='H2Foot titrecatégorie'>Football</h2>
				<a  href='groupList.php?sport=Football&liste=8'>
					<div class='sportFoot' >
						<p class='catégoriedescription'>Groupe de discussion sur le foot</p>
						<img src="img/plus.svg">	
					</div>
				</a>
			</div>
		</article>

		<article class='contenu'>
			<div class='basket'>
				<h2 class='H2Basket titrecatégorie'>Basket</h2>
				<a  href='groupList.php?sport=Basketball&liste=8'>
					<div class='sportBasket' >
						<p class='catégoriedescription'>Groupe de discussion sur le basket</p>
						<img src="img/plus.svg">	
					</div>
				</a>
			</div>
		</article>

		<article class='contenu'>
			<div class='hockey'>
				<h2 class='H2Hockey titrecatégorie'>Hockey</h2>
				<a  href='groupList.php?sport=Hockey&liste=8'>
					<div class='sportHockey' >
						<p class='catégoriedescription'>Groupe de discussion sur le hockey</p>
						<img src="img/plus.svg">	
					</div>
				</a>
			</div>
		</article>

		<article class='contenu'>
			<div class='Rugby'>
				<h2 class='H2Rugby titrecatégorie'>Rugby</h2>
				<a  href='groupList.php?sport=Rugby&liste=8'>
					<div class='sportRugby' >
						<p class='catégoriedescription'>Groupe de discussion sur le Rugby</p>
						<img src="img/plus.svg">	
					</div>
				</a>
			</div>
		</article>

		<article class='contenu'>
			<div class='tennis'>
				<h2 class='H2Tennis titrecatégorie'>Tennis</h2>
				<a  href='groupList.php?sport=Tennis&liste=8'>
					<div class='sportTennis' >
						<p class='catégoriedescription'>Groupe de discussion sur le tennis</p>
						<img src="img/plus.svg">	
					</div>
				</a>
			</div>
		</article>

		<article class='contenu'>
			<div class='autres'>
				<h2 class='H2Autres titrecatégorie'>Autres</h2>
				<a  href='groupList.php?sport=Autres&liste=8'>
					<div class='sportAutres' >
						<p class='catégoriedescription'>Dans cette catégorie vous retrouvez tous les autres sports</p>
						<img src="img/plus.svg">	
					</div>
				</a>
			</div>
		</article>
	</section>

	

	<?php include('footer.php');?>

	<script
		  src="https://code.jquery.com/jquery-3.4.1.min.js"
		  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
          crossorigin="anonymous">
    </script>
	<script type="text/javascript">
		// ---- fenetre choix inscription connexion ---//
		$(document).ready(function(){
		  $('#profil').click(function(){
		    $('#myPopup').toggle(5);
		});
		});


	</script>

</body>
</html>