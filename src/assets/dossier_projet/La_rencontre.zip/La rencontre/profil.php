<?php 
session_start()
?>

<!DOCTYPE html>
<html lang="fr" dir="ltr">

<head>
  <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0" />

  <!--   Lien de nos feuille de style -->
  <link rel="stylesheet" href="styleall.css">
  <!-- ---->

  <link rel="stylesheet" href="https://use.typekit.net/fmb4ffg.css">
  <link href="https://fonts.googleapis.com/css?family=Kaushan+Script|Lobster|Roboto&display=swap" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.6.6/sweetalert2.css">

  <title>Profil</title>
</head>

<body class="page">

  <?php include('header.php');?>

  <div class='bandeauRouge'>
    <div class='infoPerso'>
      <img src='img/photoprofil.jpg' alt='votre photo de profil' class='photoProfil'/>
      <div>
        <h2 class='prenom'>Martin Aubineau | 18ans</h2>
        <div class='infoComplementaire'>
          <img src="img/localisationNoir.png" alt='icone localisation'/>
          <p>Auzouer en touraine</p>
        </div>
        <p>mael.richard@my-digital-school.org</p>
        <p>ur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam</p>
      </div>  
    </div>

    <div class='modifDeco'>
      <a>modifier</a>
      <a href='deconnexion.php'>deconnexion</a>
    </div>  
  </div>

  <div class='containerInfoPerso'>
    <div class='mesDiscussion'>
      <div class='debordementdessus'></div>
      <div class='titreInfoProfil'>
        <img src="img/chat.png" class='iconeInfo'>
        <h2>Mes Discussions :</h2>
      </div>
      <!------------->

      <!--- groupe 1 --->
      <div class='containerGroup'>
        <div class='imageGroup'>
          <img src='img/img_groupe/groupeFootballmatch.svg'/>
        </div>
        <div class='titreGroupe'>
          <h3>Sin autem ad adulescentiam perduxissent, dirimi tamen interd</h3>
          <div class='infoGroup'>
            <p>By <span class='red'>alex</span> | 18/02/2020</p>
          </div>
        </div>
        <div class='callToAction'>
          <div class='onlineGroup'>
            <span class='rondVert'></span><p> 13 en ligne</p>
          </div>
          <a class='buttonRejoindre' href="message.php?id_groupe=30">REJOINDRE</a> 
        </div>
      </div>


      <!--- groupe 2 --->
      <div class='containerGroup'>
        <div class='imageGroup'>
          <img src='img/img_groupe/groupeFootballmatch.svg'/>
        </div>
        <div class='titreGroupe'>
          <h3>Thiago Silva va mieux !</h3>
          <div class='infoGroup'>
            <p>By <span class='red'>alex</span> | 18/02/2020</p>
          </div>
        </div>
        <div class='callToAction'>
          <div class='onlineGroup'>
            <span class='rondVert'></span><p> 13 en ligne</p>
          </div>
          <a class='buttonRejoindre' href="message.php?id_groupe=30">REJOINDRE</a> 
        </div>
      </div>

      <!--- bouton crée une discussion -->

      <a href='group_creation.php' class='boutonCreaGr'>Créer un discussion</a>
      <!------------->
    </div>
    <div class='mesInfo'>
      <div class='debordementdessus'></div>
      <div class='titreInfoProfil'>
        <img src='img/profil.svg' class='iconeInfo'>
        <h2>Mes Infos:</h2>
      </div>
      <!------------->

      <div class='infoSport'>
        <img src="img/Football.svg" alt='icone balon de foot'>
        <p>Fc Barcelone Paris</p>
      </div>

      <div class='infoSport'>
        <img src="img/Football.svg" alt='icone balon de foot'>
        <p>Fc Barcelone Paris</p>
      </div>

      <div class='infoSport'>
        <img src="img/Football.svg" alt='icone balon de foot'>
        <p>Fc Barcelone Paris</p>
      </div>

      <div class='infoSport'>
        <img src="img/premium.png" alt='icone premium'>
        <p>Compte Premium</p>
      </div>

      <!------------->
    </div>
  </div>
  

  <?php include('footer.php');?> 
</body>
</html>
