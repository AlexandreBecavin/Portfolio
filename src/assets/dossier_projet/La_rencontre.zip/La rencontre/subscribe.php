<?php
require 'bdd.php';

$insertmbr = $connexion->prepare("INSERT INTO newsletter(mail) VALUES(?)");
$insertmbr->execute(array($_POST['email']));
?>