$(document).ready(function(){
  $('.hamburger').click(function(){
      // HAMBURGER ANIMATION  //
    $('.block_logo').toggleClass('open')

    $('.hamburger__span--first').toggleClass('hamburger-cross-span-first')
    $('.hamburger__span--second').toggleClass('hamburger-cross-span-second')
    $('.hamburger__span--third').toggleClass('hamburger-cross-span-third')
    $('.hamburger__span').toggleClass('hamburger-shadow-removed')
    // BG MENU ANIMATED  //
    $('.menu').toggleClass('open');
    $('.bg-menu-animated__div-first').toggleClass('open');
    $('.bg-menu-animated__div-second').toggleClass('open');
    $('.bg-menu-animated__div-third').toggleClass('open');
    // MENU ANIMATION  //
    $('.menu__li--first').toggleClass('open');
    $('.menu__li--second').toggleClass('open');
    $('.menu__li--third').toggleClass('open');
    $('.menu__li--fourth').toggleClass('open');
  });

  $('.btn_accessibilite').click(function(){
    $('.modal_accessibilite').toggleClass('open');
  });

  $('.taille1').click(function(){
    $('body').removeClass('police2');
    $('body').removeClass('police3');
    $('body').removeClass('police4');
  });

  $('.taille2').click(function(){
    $('body').toggleClass('police2');
    $('body').removeClass('police3');
    $('body').removeClass('police4');
  });

  $('.taille3').click(function(){
    $('body').toggleClass('police3');
    $('body').removeClass('police2');
    $('body').removeClass('police4');
  });

  $('.taille4').click(function(){
    $('body').toggleClass('police4');
    $('body').removeClass('police3');
    $('body').removeClass('police2');
  });

  $('.contrast2').click(function(){
    $('body').toggleClass('hight_contrast');
  });
  $('.contrast1').click(function(){
    $('body').removeClass('hight_contrast');
  });
});

